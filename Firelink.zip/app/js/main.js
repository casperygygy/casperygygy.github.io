
(()=>{
    document.querySelector('.top-line__currency')
    .addEventListener('click', (event)=>{
        if (event.target.tagName.toLowerCase() === 'a' && (event.target.parentNode.classList.contains('language') || event.target.parentNode.classList.contains('currency'))) {
            let childrens = event.target.parentNode.children
            for (let i = 0; i < childrens.length; i++) {
                childrens[i].classList.remove('active')
                
            }
            event.target.classList.add('active')
        }
        
    })
})();
;(()=>{
    document.getElementById('login').addEventListener("click", function() {
        document.querySelector('.modal-bg').style.display = "flex";
        document.querySelector('html').style.overflow = "hidden";
    });
    
    document.querySelector('.modal__close').addEventListener("click", function() {
        document.querySelector('.modal-bg').style.display = "none";
        document.querySelector('html').style.overflow = "visible";
    });
})();
;(() => {
    const slider = document.querySelector('.slider__wrapper')
    const dots = document.querySelectorAll('.dot')
    
    let left = -100;
    document.querySelector('.slider__next').addEventListener('click', ()=>{
        left += -100
        for (let i = 0; i < dots.length; i++) {
            dots[i].classList.remove('dot--active')
        }

        if ( left <= -300) {
            left = 0
            
        }
        slider.style.left = left + "%"
     
        check(left)

        })
    document.querySelector('.slider__prev').addEventListener('click', ()=>{
        left += 100
        for (let i = 0; i < dots.length; i++) {
            dots[i].classList.remove('dot--active')
        }
        if ( left >= 100) {
            left = -200
            
        }
        slider.style.left = left + "%"

        check(left)
    })
    

    document.querySelector('.slider__dots').addEventListener('click', function(e) {
        for (let i = 0; i < dots.length; i++) {
            dots[i].classList.remove('dot--active')
        }
        if(event.target.id == 'dot1') {
            slider.style.left = 0 + "%"
            left = 0
            
        } else
        if(event.target.id == 'dot2') {
            slider.style.left = -100 + "%"
            left = -100
            
        } else
        if(event.target.id == 'dot3') {
            slider.style.left = -200 + "%"
            left = -200
        }
        check(left)
    })

    function check(left) {
        if(left == 0) {
            dots[0].classList.add('dot--active')
        } else
        if(left == -100) {
            dots[1].classList.add('dot--active')
        } else 
        if(left == -200) {
            dots[2].classList.add('dot--active')
        } 
    }
})()